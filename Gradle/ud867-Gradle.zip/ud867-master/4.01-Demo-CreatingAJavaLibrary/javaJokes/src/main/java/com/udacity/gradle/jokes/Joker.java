package com.udacity.gradle.jokes;

public class Joker {
    public String getJoke(){
        return "This is totally a funny joke";
    }
}